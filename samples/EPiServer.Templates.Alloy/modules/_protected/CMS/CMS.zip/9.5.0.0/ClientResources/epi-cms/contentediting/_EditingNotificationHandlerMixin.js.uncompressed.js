define("epi-cms/contentediting/_EditingNotificationHandlerMixin", [
    "dojo/_base/declare",
    "dojo/_base/lang",

    "epi/shell/DestroyableByKey",
    "epi-cms/plugin-area/edit-notifications"
], function (
    declare,
    lang,

    DestroyableByKey,
    editNotifications
) {

    return declare([DestroyableByKey], {
        // summary:
        //    Watches and handles plugged editing notifications.
        // tags:
        //    internal abstract

        _handlesKey: "_EditingNotificationHandles",

        constructor: function (options) {
            declare.safeMixin(this, options);
            this.own(editNotifications.on("added, removed", this._watchNotifications.bind(this)));
        },

        postscript: function () {
            this.inherited(arguments);
            this._watchNotifications();
        },

        _watchNotifications: function () {
            // summary:
            //      Updates notifications when notifications are added or removed
            // tags:
            //      private

            this.destroyByKey(this._handlesKey);

            editNotifications.get().forEach(function (notification) {
                if (notification) {
                    this.ownByKey(
                        this._handlesKey,
                        notification.watch("notification",
                            lang.hitch(this, this._defaultNotificationWatchHandler))
                    );
                }
            }, this);
        },

        _defaultNotificationWatchHandler: function (/*String*/name, /*Object*/oldValue, /*Object*/newValue) {
            // summary:
            //      Default handler for editig notifications. Must be implemented by inherited components.
            // tags:
            //    protected abstract
        },

        _updateNotifications: function (contentData, context) {
            // summary:
            //      Updates all notifications with current content data and context.
            // tags:
            //    protected

            editNotifications.get().forEach(function (notification) {
                if (notification) {
                    notification.set("invokeActionValue", {contentData: contentData, context: context});
                }
            });
        },

        _suspendNotifications: function () {
            // summary:
            //      Suspends all notifications
            // tags:
            //    protected

            editNotifications.get().forEach(function (notification) {
                if (notification) {
                    notification.set("isSuspended", true);
                }
            });
        },

        _wakeUpNotifications: function () {
            // summary:
            //      Wakes all notifications up.
            // tags:
            //    protected

            editNotifications.get().forEach(function (notification) {
                if (notification) {
                    notification.set("isSuspended", false);
                }
            });
        }
    });
});
