define([
	'./functional/Keyboard',
	'./functional/KeyboardTab',
	'./functional/selector',
	'./functional/editor',
	'./functional/tree'
], function(){});