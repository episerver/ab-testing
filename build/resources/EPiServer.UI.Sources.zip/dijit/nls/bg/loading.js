define(
({
	loadingState: "Зареждане...",
	errorState: "Съжаляваме, възникна грешка"
})
);
