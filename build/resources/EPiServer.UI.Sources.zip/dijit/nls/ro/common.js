define(
({
	buttonOk: "OK",
	buttonCancel: "Anulare",
	buttonSave: "Salvare",
	itemClose: "Închidere"
})
);
